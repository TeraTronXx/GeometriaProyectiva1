Luis Miguel Pinto Maguiña - Master en Computación Gráfica, Realidad Virtual y Simulación

Cada carpeta, contiene un ejercicio distinto y los ficheros necesarios para el mismo. 
En el caso del ejercicio 4, necesita crear 3 variables antes de poder ejecutar la funcion. Viene explicado en el codigo del fichero ejercicio4.m